package com.gl.SBh2database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SBh2databaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SBh2databaseApplication.class, args);
	}

}
